"""Build a query store with an EXACT teacher-query budget.

budget B = number of teacher forward passes = number of stored (image, logits) pairs.
Augmentation and mixup happen before the query, so they are inside B, not on top of it:

    for each source s with share w_s:   n_s = w_s * B queries
        n_base_s = ceil(n_s / views_per_base_s) base images
        each base image yields views_per_base_s augmented views
    batches of views are mixed (function-matching mixup), rounded to uint8, sent to the teacher once.

Training afterwards reads only the store and never calls the teacher.
Resumable: progress is committed per chunk; restart with the same config continues where it stopped.
"""
import math
import random
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Subset
from tqdm.auto import tqdm

from .augment import build_augment, mixup_u8
from .data import coverage
from .models import load_teacher
from .sources import build_source
from .utils import device, ledger, read_json, store_dir, write_json


class _Items(Dataset):
    def __init__(self, plan, sources, aug, seed):
        self.plan, self.sources, self.aug, self.seed = plan, sources, aug, int(seed)

    def __len__(self):
        return len(self.plan)

    def __getitem__(self, i):
        sid, b, _view = (int(z) for z in self.plan[i])
        img = self.sources[sid].base(b)
        x = torch.from_numpy(np.ascontiguousarray(img)).permute(2, 0, 1).contiguous()
        if self.aug is not None:
            s = (self.seed * 1_000_003 + int(i)) % (2 ** 62)   # deterministic per query index
            torch.manual_seed(s)
            random.seed(s)
            x = self.aug(x)
        return x, i


def make_plan(source_cfgs, budget, seed):
    """Returns labels, plan[B,3] = (source_id, base_idx, view_idx) shuffled, and per-source counts."""
    active = [(k, v) for k, v in source_cfgs.items() if float((v or {}).get("weight", 0)) > 0]
    if not active:
        raise ValueError("no source has weight > 0")
    wsum = sum(float(v["weight"]) for _, v in active)
    counts, acc = [], 0
    for j, (_, v) in enumerate(active):
        n = budget - acc if j == len(active) - 1 else int(round(budget * float(v["weight"]) / wsum))
        counts.append(n)
        acc += n
    rows = []
    for sid, ((_, v), n) in enumerate(zip(active, counts)):
        k = int(v.get("views_per_base", 1))
        j = np.arange(n)
        rows.append(np.stack([np.full(n, sid), j // k, j % k], 1))
    plan = np.concatenate(rows).astype(np.int64)
    np.random.default_rng([int(seed), 99]).shuffle(plan)
    return [k for k, _ in active], plan, counts


def _sources(labels, source_cfgs, size, seed, mean, std, data_root):
    return [build_source(l, source_cfgs[l], size, seed, mean, std, data_root) for l in labels]


def _iterate(teacher, items, start, end, bs, nw, mix_cfg, seed, dev):
    """Yields (pos, uint8 images, teacher logits fp32 cpu, mixed flags) for queries [start, end)."""
    loader = DataLoader(Subset(items, range(start, end)), batch_size=bs, shuffle=False,
                        num_workers=nw, pin_memory=True)
    pos = start
    for x, idx in loader:
        assert int(idx[0]) == pos, "query order broke; refusing to write misaligned logits"
        x, mixed = mixup_u8(x, mix_cfg, np.random.default_rng([int(seed), 7, pos]))
        with torch.no_grad():
            z = teacher(x.to(dev, non_blocking=True).float().div_(255)).float().cpu()
        yield pos, x, z, mixed
        pos += len(x)


def build_store(cfg, kind="transfer"):
    """kind='transfer' uses cfg.query; kind='monitor' uses cfg.monitor (natural images, no aug/mixup)."""
    q = cfg["query"]
    size = int(q["image_size"])
    if kind == "transfer":
        src_cfg, aug_cfg, mix_cfg = q["sources"], q.get("augment"), q.get("mixup")
        budget, seed = int(q["budget"]), int(q["seed"])
    else:
        m = cfg["monitor"]
        src_cfg = {"monitor": {**m["source"], "weight": 1.0, "views_per_base": 1}}
        aug_cfg, mix_cfg = {"name": "none"}, {"p": 0.0}
        budget, seed = int(m["n"]), int(m.get("seed", 12345))

    out = store_dir(cfg, kind)
    meta = read_json(out / "meta.json")
    if meta and meta.get("complete"):
        print(f"[{kind}] store already complete: {out}")
        return out
    out.mkdir(parents=True, exist_ok=True)

    dev = device()
    teacher = load_teacher(cfg).to(dev)
    mean, std = teacher.mean_list, teacher.std_list
    C = int(cfg["num_classes"])

    labels, plan, counts = make_plan(src_cfg, budget, seed)
    plan_path = out / "plan.npy"
    if plan_path.exists():
        if not np.array_equal(np.load(plan_path), plan):
            raise RuntimeError(f"existing plan in {out} differs from config; delete the folder to rebuild")
    else:
        np.save(plan_path, plan)

    srcs = _sources(labels, src_cfg, size, seed, mean, std, cfg["paths"].get("data"))
    for l, s, n, v in zip(labels, srcs, counts, [src_cfg[l].get("views_per_base", 1) for l in labels]):
        nb = math.ceil(n / int(v))
        note = ""
        if getattr(s, "finite", False) and nb > len(s):
            note = f"  (WARNING: needs {nb} bases, source has {len(s)} -> bases repeat)"
        print(f"[{kind}] source {l:>16}: {n:>9,} queries = {nb:,} bases x {v} views{note}")

    ldtype = np.float16 if cfg.get("store_logits_dtype", "float16") == "float16" else np.float32
    prog = read_json(out / "progress.json", {"done": 0})
    mode = "r+" if prog["done"] > 0 else "w+"
    images = np.lib.format.open_memmap(out / "images.npy", mode=mode, dtype=np.uint8, shape=(budget, 3, size, size))
    logits = np.lib.format.open_memmap(out / "logits.npy", mode=mode, dtype=ldtype, shape=(budget, C))
    mixed = np.lib.format.open_memmap(out / "mixed.npy", mode=mode, dtype=np.bool_, shape=(budget,))

    items = _Items(plan, srcs, build_augment(aug_cfg, size), seed)
    bs = int(q.get("batch_size", 512))
    chunk = max(bs, (int(q.get("chunk", 100_000)) // bs) * bs)   # multiple of bs -> resume-safe batches
    nw = int(q.get("num_workers", 4))
    done = int(prog["done"])
    t0 = time.time()
    pbar = tqdm(total=budget, initial=done, desc=f"querying teacher ({kind})", unit="img")
    while done < budget:
        end = min(budget, done + chunk)
        for pos, x, z, mx in _iterate(teacher, items, done, end, bs, nw, mix_cfg, seed, dev):
            n = len(x)
            images[pos:pos + n] = x.numpy()
            logits[pos:pos + n] = z.numpy().astype(ldtype)
            mixed[pos:pos + n] = mx
            pbar.update(n)
        images.flush(); logits.flush(); mixed.flush()
        ledger(cfg, kind, end - done, store=out.name, range=[done, end])
        done = end
        write_json(out / "progress.json", {"done": done})
    pbar.close()

    cov = {"all": coverage(logits)}
    for sid, l in enumerate(labels):
        cov[l] = coverage(logits[plan[:, 0] == sid]) if (plan[:, 0] == sid).any() else None
    write_json(out / "coverage.json", cov)
    write_json(out / "meta.json", {
        "complete": True, "kind": kind, "n": budget, "teacher_queries": budget, "num_classes": C,
        "image_shape": [3, size, size], "logits_dtype": str(np.dtype(ldtype)), "sources": labels,
        "source_counts": dict(zip(labels, counts)), "teacher": cfg["teacher"], "teacher_mean": mean,
        "teacher_std": std, "query_cfg": q if kind == "transfer" else cfg["monitor"],
        "seconds_last_session": round(time.time() - t0, 1),
    })
    print(f"[{kind}] done -> {out}\n[{kind}] coverage (all): relH={cov['all']['rel_entropy']:.3f}, "
          f"classes>=0.1%: {cov['all']['classes_covered_0.1pct']}/{C}, top share={cov['all']['top_class_share']:.3f}")
    return out


def probe(cfg, n=20_000, only=None):
    """Phase-0 style coverage check of every listed source under the configured augmentation, without
    storing anything. These queries are logged in the ledger as 'probe' (design cost, not training data)."""
    q = cfg["query"]
    size, seed = int(q["image_size"]), int(q["seed"]) + 777
    dev = device()
    teacher = load_teacher(cfg).to(dev)
    mean, std = teacher.mean_list, teacher.std_list
    aug = build_augment(q.get("augment"), size)
    results = {}
    for label, scfg in q["sources"].items():
        active = float((scfg or {}).get("weight", 0)) > 0
        if (only and label not in only) or (not only and not active):
            continue
        one = {label: {**(scfg or {}), "weight": 1.0}}
        labels, plan, _ = make_plan(one, n, seed)
        srcs = _sources(labels, one, size, seed, mean, std, cfg["paths"].get("data"))
        items = _Items(plan, srcs, aug, seed)
        zs = [z for _, _, z, _ in _iterate(teacher, items, 0, n, int(q.get("batch_size", 512)),
                                           int(q.get("num_workers", 4)), q.get("mixup"), seed, dev)]
        cov = coverage(torch.cat(zs).numpy())
        results[label] = cov
        ledger(cfg, "probe", n, source=label, augment=(q.get("augment") or {}).get("name"))
        print(f"[probe] {label:>16}: relH={cov['rel_entropy']:.3f}  classes>=0.1%={cov['classes_covered_0.1pct']}"
              f"  top share={cov['top_class_share']:.3f}")
    return results
