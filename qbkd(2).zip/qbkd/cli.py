"""python -m qbkd.cli <command> --config configs/cifar10_r34_r18.yaml [key=value ...]

commands
  verify-teacher   teacher test accuracy + the normalisation it uses (sanity check, no budget cost)
  probe            Phase-0 coverage of every source under the configured augmentation (logged as 'probe')
  query            build the transfer store with exactly query.budget teacher queries
  monitor          build the natural-image monitor store (monitor.n queries, logged separately)
  train            train one student on the store (no teacher calls)   [--seed S] [--run NAME]
  connect          mode-connectivity between two students              [--endpoints a.pt b.pt] [--run NAME]
  report           collect every result into results.csv
"""
import argparse
import csv
import json

from .utils import exp_dir, load_config, read_json


def cmd_verify_teacher(cfg, a):
    from .data import accuracy, predict_test, test_loader
    from .models import load_teacher
    from .utils import device

    dev = device()
    t = load_teacher(cfg).to(dev)
    p, y = predict_test(t, test_loader(cfg), dev, amp=False)
    print(f"teacher {cfg['teacher']}  mean={t.mean_list} std={t.std_list}  test acc={accuracy(p, y):.2f}%")


def cmd_report(cfg, a):
    root = exp_dir(cfg)
    rows = []
    for r in sorted(root.glob("students/*/result.json")):
        rows.append({"type": "student", **read_json(r)})
    for s in sorted(root.glob("curves/*/summary.json")):
        d = read_json(s)
        rows.append({"type": "curve", "run": s.parent.name, "teacher_queries": d["teacher_queries_used"],
                     "best_t": d["best_point"]["t"], "test_acc_best_point": d["best_point"].get("test_acc"),
                     "test_acc_start_ownBN": d["endpoint_own_bn"]["start"].get("test_acc"),
                     "test_acc_end_ownBN": d["endpoint_own_bn"]["end"].get("test_acc"),
                     "ens_endpoints": d["ensemble_endpoints"]["test_acc"],
                     "ens_curve_all": d["ensemble_curve_all_grid"]["test_acc"],
                     "max_store_kd_on_curve": d["max_store_kd_on_curve"]})
    ledger = root / "query_ledger.jsonl"
    if ledger.exists():
        tot = {}
        for line in ledger.read_text().splitlines():
            rec = json.loads(line)
            tot[rec["purpose"]] = tot.get(rec["purpose"], 0) + rec["queries"]
        print("teacher queries by purpose:", tot)
    if not rows:
        print("no results yet")
        return
    keys = sorted({k for r in rows for k in r})
    with open(root / "results.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    for r in rows:
        print({k: (round(v, 2) if isinstance(v, float) else v) for k, v in r.items()})
    print(f"-> {root / 'results.csv'}")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="qbkd")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name):
        p = sub.add_parser(name)
        p.add_argument("--config", required=True)
        p.add_argument("overrides", nargs="*", help="dotted overrides, e.g. query.budget=100000")
        return p

    add("verify-teacher")
    p = add("probe")
    p.add_argument("--n", type=int, default=20_000)
    p.add_argument("--sources", nargs="*", default=None, help="labels to probe (default: weight>0)")
    add("query")
    add("monitor")
    p = add("train")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--run", default=None)
    p = add("connect")
    p.add_argument("--endpoints", nargs="*", default=None)
    p.add_argument("--run", default=None)
    add("report")
    a = ap.parse_args(argv)
    cfg = load_config(a.config, a.overrides)

    if a.cmd == "verify-teacher":
        cmd_verify_teacher(cfg, a)
    elif a.cmd == "probe":
        from .query import probe
        probe(cfg, a.n, a.sources)
    elif a.cmd == "query":
        from .query import build_store
        build_store(cfg, "transfer")
    elif a.cmd == "monitor":
        from .query import build_store
        build_store(cfg, "monitor")
    elif a.cmd == "train":
        from .train import train_student
        train_student(cfg, a.seed, a.run)
    elif a.cmd == "connect":
        from .connect import run_connect
        run_connect(cfg, a.endpoints, a.run)
    elif a.cmd == "report":
        cmd_report(cfg, a)


if __name__ == "__main__":
    main()
