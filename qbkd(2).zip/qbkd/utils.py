"""Config loading, run directories, hashing, the query ledger."""
import copy
import hashlib
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
import yaml


# ---------------------------------------------------------------- config
def _deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def _load_yaml(path):
    path = Path(path)
    cfg = yaml.safe_load(path.read_text()) or {}
    base = cfg.pop("_base_", None)
    if base:
        cfg = _deep_merge(_load_yaml(path.parent / base), cfg)
    return cfg


def _set_dotted(d, dotted, value):
    keys = dotted.split(".")
    for k in keys[:-1]:
        d = d.setdefault(k, {})
    if value is None and keys[-1] in d:      # key=null deletes (e.g. remove a source)
        del d[keys[-1]]
    else:
        d[keys[-1]] = value


def load_config(path, overrides=()):
    """overrides: ["query.budget=100000", "train.temperature=4", ...]"""
    cfg = _load_yaml(path)
    for ov in overrides:
        if "=" not in ov:
            raise ValueError(f"override must look like key=value, got {ov!r}")
        k, v = ov.split("=", 1)
        _set_dotted(cfg, k.strip(), yaml.safe_load(v))
    return cfg


# ---------------------------------------------------------------- paths / tags
def exp_dir(cfg):
    p = Path(cfg["paths"]["root"]) / cfg["name"]
    p.mkdir(parents=True, exist_ok=True)
    return p


def short_hash(obj, n=8):
    s = json.dumps(obj, sort_keys=True, default=str)
    return hashlib.sha1(s.encode()).hexdigest()[:n]


def query_tag(cfg):
    """Identifies a transfer store. Any change to what the teacher is asked changes the tag."""
    q = cfg["query"]
    key = {k: q.get(k) for k in ("budget", "seed", "image_size", "augment", "mixup")}
    key["sources"] = {k: v for k, v in q["sources"].items() if float((v or {}).get("weight", 0)) > 0}
    key["teacher"] = cfg["teacher"]
    return f"b{q['budget']}_{short_hash(key)}"


def monitor_tag(cfg):
    m = cfg["monitor"]
    key = {"monitor": m, "teacher": cfg["teacher"], "size": cfg["query"]["image_size"]}
    return f"n{m['n']}_{short_hash(key)}"


def store_dir(cfg, kind):
    if kind == "transfer":
        return exp_dir(cfg) / "query" / query_tag(cfg)
    if kind == "monitor":
        return exp_dir(cfg) / "monitor" / monitor_tag(cfg)
    raise ValueError(kind)


# ---------------------------------------------------------------- misc
def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def write_json(path, obj):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, default=str))
    tmp.replace(path)


def read_json(path, default=None):
    path = Path(path)
    if not path.exists():
        return default
    return json.loads(path.read_text())


def ledger(cfg, purpose, n, **extra):
    """Every teacher forward pass is recorded here. Sum of 'transfer' rows = the query budget used."""
    rec = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "purpose": purpose, "queries": int(n), **extra}
    with open(exp_dir(cfg) / "query_ledger.jsonl", "a") as f:
        f.write(json.dumps(rec, default=str) + "\n")
