"""Reading query stores, the real test set, and all metrics (coverage, accuracy, agreement)."""
import math
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from .utils import read_json


# ------------------------------------------------------------------ query store
class StoreDataset(Dataset):
    """(uint8 image [3,H,W], teacher logits float32 [C], index). Memmaps open lazily per worker."""

    def __init__(self, path, indices=None):
        self.path = Path(path)
        meta = read_json(self.path / "meta.json")
        if not meta or not meta.get("complete"):
            raise RuntimeError(f"store {self.path} is missing or incomplete; run the query step first")
        self.meta = meta
        n = meta["n"]
        self.indices = np.arange(n) if indices is None else np.asarray(indices)
        self._img = self._log = None

    def _open(self):
        if self._img is None:
            self._img = np.load(self.path / "images.npy", mmap_mode="r")
            self._log = np.load(self.path / "logits.npy", mmap_mode="r")

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, k):
        self._open()
        i = int(self.indices[k])
        return (torch.from_numpy(np.array(self._img[i])),
                torch.from_numpy(np.array(self._log[i], dtype=np.float32)), i)


def load_logits(path):
    return np.load(Path(path) / "logits.npy", mmap_mode="r")


def store_loader(path, batch_size, num_workers, indices=None, shuffle=False, sampler=None, drop_last=False):
    ds = StoreDataset(path, indices)
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle and sampler is None, sampler=sampler,
                      num_workers=num_workers, pin_memory=True, drop_last=drop_last,
                      persistent_workers=num_workers > 0)


# ------------------------------------------------------------------ real test set (reporting only)
def test_loader(cfg, batch_size=500, num_workers=2):
    import torchvision.datasets as D
    import torchvision.transforms as T

    root = cfg["paths"].get("data", "./data")
    cls = {"cifar10": D.CIFAR10, "cifar100": D.CIFAR100}[cfg["dataset"]]
    ds = cls(root, train=False, download=True, transform=T.ToTensor())
    return DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=True)


# ------------------------------------------------------------------ metrics
def coverage(logits, temps=(1, 4, 20), chunk=200_000):
    """Frank & Davis relative entropy of the teacher argmax histogram, plus Priyanka's extras."""
    logits = np.asarray(logits) if not isinstance(logits, np.memmap) else logits
    N, C = logits.shape
    hist = np.zeros(C, dtype=np.int64)
    ent = {T: 0.0 for T in temps}
    for s in range(0, N, chunk):
        z = torch.from_numpy(np.asarray(logits[s:s + chunk], dtype=np.float32))
        hist += np.bincount(z.argmax(1).numpy(), minlength=C)
        for T in temps:
            p = F.softmax(z / T, 1)
            ent[T] += float((-(p * p.clamp_min(1e-12).log()).sum(1) / math.log(C)).sum())
    p = hist / max(hist.sum(), 1)
    nz = p[p > 0]
    return {
        "n": int(N),
        "rel_entropy": float(-(nz * np.log(nz)).sum() / math.log(C)),
        "classes_covered_0.1pct": int((p >= 0.001).sum()),
        "classes_never_predicted": int((hist == 0).sum()),
        "top_class_share": float(p.max()),
        "mean_norm_softmax_entropy": {f"T{T}": ent[T] / N for T in temps},
        "argmax_hist": hist.tolist(),
    }


@torch.no_grad()
def predict_test(model, loader, dev, amp=True):
    model.eval()
    probs, labels = [], []
    for x, y in loader:
        with torch.autocast("cuda", dtype=torch.float16, enabled=amp and dev.type == "cuda"):
            z = model(x.to(dev, non_blocking=True))
        probs.append(F.softmax(z.float(), 1).cpu())
        labels.append(y)
    return torch.cat(probs), torch.cat(labels)


@torch.no_grad()
def predict_store(model, loader, dev, T=None, amp=True):
    """Returns student probs, teacher argmax, and (optional) KD loss at temperature T."""
    model.eval()
    probs, targ, kd_sum, n = [], [], 0.0, 0
    for x, t, _ in loader:
        x = x.to(dev, non_blocking=True).float().div_(255)
        t = t.to(dev, non_blocking=True)
        with torch.autocast("cuda", dtype=torch.float16, enabled=amp and dev.type == "cuda"):
            z = model(x)
        z = z.float()
        if T is not None:
            kd_sum += float(F.kl_div(F.log_softmax(z / T, 1), F.softmax(t / T, 1), reduction="sum") * T * T)
        probs.append(F.softmax(z, 1).cpu())
        targ.append(t.argmax(1).cpu())
        n += len(x)
    out = {"probs": torch.cat(probs), "teacher_argmax": torch.cat(targ)}
    if T is not None:
        out["kd_loss"] = kd_sum / max(n, 1)
    return out


def accuracy(probs, labels):
    return float((probs.argmax(1) == labels).float().mean() * 100)
