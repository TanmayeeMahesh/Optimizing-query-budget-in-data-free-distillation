"""Mode-connecting curves (Garipov et al., 2018) for ANY nn.Module.

The original repo re-implements every layer as a curve layer. Here the architecture is untouched:
weights(t) = sum_j c_j(t) * theta_j is computed over all parameters, and the forward pass runs the
ordinary model through torch.func.functional_call. Swapping the student architecture needs no new code.

  bezier, K bends:  c_j(t) = binom(K-1, j) t^j (1-t)^(K-1-j)     (K=3 is the paper's quadratic Bezier)
  polychain:        piecewise-linear through the K points
  linear baseline:  polychain with K=2 (no trainable bend)
Endpoints theta_0, theta_{K-1} are frozen; only the interior bends are trained.
BatchNorm running stats are not interpolated; they are recomputed for every t (see materialize).
"""
import copy
from math import comb

import torch
import torch.nn as nn
from torch.func import functional_call


def _key(n):
    return n.replace(".", "__")


class Curve(nn.Module):
    def __init__(self, base, start_sd, end_sd, num_bends=3, kind="bezier"):
        super().__init__()
        if num_bends < 2:
            raise ValueError("num_bends >= 2")
        self.base, self.kind, self.K = base, kind, int(num_bends)
        for p in self.base.parameters():
            p.requires_grad_(False)
        self.pnames = [n for n, _ in base.named_parameters()]
        for n in self.pnames:
            self.register_buffer("start__" + _key(n), start_sd[n].detach().clone().float())
            self.register_buffer("end__" + _key(n), end_sd[n].detach().clone().float())
        self.bends = nn.ModuleList()
        for j in range(1, self.K - 1):
            f = j / (self.K - 1)
            self.bends.append(nn.ParameterDict({
                _key(n): nn.Parameter((1 - f) * start_sd[n].detach().float() + f * end_sd[n].detach().float())
                for n in self.pnames}))

    def trainable(self):
        return list(self.bends.parameters())

    def _point(self, j, n):
        if j == 0:
            return getattr(self, "start__" + _key(n))
        if j == self.K - 1:
            return getattr(self, "end__" + _key(n))
        return self.bends[j - 1][_key(n)]

    def coeffs(self, t):
        t = float(t)
        K = self.K
        if self.kind == "bezier":
            return [comb(K - 1, j) * t ** j * (1 - t) ** (K - 1 - j) for j in range(K)]
        if self.kind == "polychain":
            s = t * (K - 1)
            i = min(int(s), K - 2)
            r = s - i
            c = [0.0] * K
            c[i], c[i + 1] = 1 - r, r
            return c
        raise KeyError(self.kind)

    def weights(self, t):
        c = self.coeffs(t)
        return {n: sum(cj * self._point(j, n) for j, cj in enumerate(c) if cj != 0.0) for n in self.pnames}

    def forward(self, x, t):
        return functional_call(self.base, self.weights(t), (x,))

    def l2(self, t):
        """Garipov's regulariser: weight decay applied to the point on the curve (matrix/conv params)."""
        w = self.weights(t)
        return sum((w[n] ** 2).sum() for n in self.pnames if w[n].ndim > 1)

    @torch.no_grad()
    def materialize(self, t, bn_loader=None, bn_batches=50, dev=None):
        """Plain nn.Module at curve position t, with BatchNorm statistics recomputed on bn_loader."""
        m = copy.deepcopy(self.base)
        sd = m.state_dict()
        for n, w in self.weights(t).items():
            sd[n].copy_(w.to(sd[n].dtype))
        if bn_loader is not None:
            bns = [mod for mod in m.modules() if isinstance(mod, nn.modules.batchnorm._BatchNorm)]
            moms = [b.momentum for b in bns]
            for b in bns:
                b.reset_running_stats()
                b.momentum = None           # cumulative average over the recompute pass
            m.train()
            for k, (x, *_rest) in enumerate(bn_loader):
                if k >= bn_batches:
                    break
                x = x.to(dev, non_blocking=True)
                m(x.float().div_(255) if x.dtype == torch.uint8 else x)
            for b, mo in zip(bns, moms):
                b.momentum = mo
        return m.eval()
