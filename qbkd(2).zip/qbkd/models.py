"""Model registry.

Every model in this pipeline takes images in [0, 1] and applies its own normalisation
internally (the `Normalized` wrapper), so stored query images never depend on a model's
preprocessing and teachers/students can be swapped from the config alone.
"""
import json

import torch
import torch.nn as nn
import torch.nn.functional as F


class Normalized(nn.Module):
    def __init__(self, model, mean, std):
        super().__init__()
        self.model = model
        self.register_buffer("mean", torch.tensor(mean, dtype=torch.float32).view(1, -1, 1, 1))
        self.register_buffer("std", torch.tensor(std, dtype=torch.float32).view(1, -1, 1, 1))

    @property
    def mean_list(self):
        return self.mean.flatten().tolist()

    @property
    def std_list(self):
        return self.std.flatten().tolist()

    def forward(self, x):
        return self.model((x - self.mean) / self.std)


# ------------------------------------------------------------------ CIFAR ResNets (students)
class BasicBlock(nn.Module):
    def __init__(self, inp, planes, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(inp, planes, 3, stride, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.shortcut = nn.Sequential()
        if stride != 1 or inp != planes:
            self.shortcut = nn.Sequential(nn.Conv2d(inp, planes, 1, stride, bias=False), nn.BatchNorm2d(planes))

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return F.relu(out + self.shortcut(x))


class ResNetCifar(nn.Module):
    """CIFAR-style ResNet: 3x3 stride-1 stem, no max-pool (same as Priyanka's student)."""

    def __init__(self, blocks, num_classes, width=64):
        super().__init__()
        self.in_planes = width
        self.conv1 = nn.Conv2d(3, width, 3, 1, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(width)
        self.layer1 = self._make(width, blocks[0], 1)
        self.layer2 = self._make(width * 2, blocks[1], 2)
        self.layer3 = self._make(width * 4, blocks[2], 2)
        self.layer4 = self._make(width * 8, blocks[3], 2)
        self.fc = nn.Linear(width * 8, num_classes)

    def _make(self, planes, n, stride):
        layers = []
        for s in [stride] + [1] * (n - 1):
            layers.append(BasicBlock(self.in_planes, planes, s))
            self.in_planes = planes
        return nn.Sequential(*layers)

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.layer4(self.layer3(self.layer2(self.layer1(out))))
        return self.fc(F.adaptive_avg_pool2d(out, 1).flatten(1))


def _timm_cifar(arch, num_classes):
    """timm ResNet with the CIFAR stem used by the `detectors` HF checkpoints."""
    import timm

    m = timm.create_model(arch, pretrained=False, num_classes=num_classes)
    m.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    m.maxpool = nn.Identity()
    return m


ARCHS = {
    "resnet18_cifar": lambda c: ResNetCifar([2, 2, 2, 2], c),
    "resnet34_cifar": lambda c: ResNetCifar([3, 4, 6, 3], c),
    "resnet18_cifar_half": lambda c: ResNetCifar([2, 2, 2, 2], c, width=32),
}


def build_arch(name, num_classes):
    if name in ARCHS:
        return ARCHS[name](num_classes)
    if name.startswith("timm_cifar:"):
        return _timm_cifar(name.split(":", 1)[1], num_classes)
    if name.startswith("timm:"):
        import timm

        return timm.create_model(name.split(":", 1)[1], pretrained=False, num_classes=num_classes)
    raise KeyError(f"unknown arch {name!r}; known: {list(ARCHS)} or timm_cifar:<name> / timm:<name>")


# ------------------------------------------------------------------ teachers
def _strip_prefix(sd):
    sd = sd.get("state_dict", sd.get("model", sd)) if isinstance(sd, dict) else sd
    return {k.replace("module.", "", 1) if k.startswith("module.") else k: v for k, v in sd.items()}


def load_teacher(cfg):
    """Returns a frozen Normalized teacher in eval mode (CPU; caller moves it)."""
    t = cfg["teacher"]
    C = cfg["num_classes"]
    kind = t["kind"]
    mean, std = t.get("mean"), t.get("std")

    if kind == "hf_timm_cifar":
        # e.g. repo edadaltocg/resnet34_cifar10 (MIT). Loads without the `detectors` package.
        from huggingface_hub import hf_hub_download

        repo = t["repo"]
        model = _timm_cifar(t.get("arch", "resnet34"), C)
        sd = torch.load(hf_hub_download(repo, t.get("filename", "pytorch_model.bin")), map_location="cpu")
        model.load_state_dict(_strip_prefix(sd), strict=True)
        if mean is None or std is None:
            try:
                pc = json.load(open(hf_hub_download(repo, "config.json")))
                pc = pc.get("pretrained_cfg", pc)
                mean, std = mean or pc["mean"], std or pc["std"]
            except Exception as e:  # noqa: BLE001
                raise ValueError(f"could not read mean/std for {repo}; set teacher.mean/std") from e

    elif kind == "detectors":
        import detectors  # noqa: F401  (registers the models in timm)
        import timm

        model = timm.create_model(t["name"], pretrained=True)
        pc = getattr(model, "pretrained_cfg", None) or {}
        mean, std = mean or pc.get("mean"), std or pc.get("std")

    elif kind == "checkpoint":
        model = build_arch(t["arch"], C)
        model.load_state_dict(_strip_prefix(torch.load(t["path"], map_location="cpu")), strict=True)

    else:
        raise KeyError(f"unknown teacher.kind {kind!r}")

    if mean is None or std is None:
        raise ValueError("teacher normalisation (mean/std) unknown; set teacher.mean and teacher.std")
    teacher = Normalized(model, list(mean), list(std)).eval()
    for p in teacher.parameters():
        p.requires_grad_(False)
    return teacher


def build_student(cfg, mean, std):
    """Student uses the teacher's normalisation stats (teacher metadata, as in Priyanka's report)."""
    return Normalized(build_arch(cfg["student"]["arch"], cfg["num_classes"]), mean, std)


def load_student_ckpt(cfg, path, map_location="cpu"):
    ck = torch.load(path, map_location=map_location)
    m = build_student(cfg, ck["mean"], ck["std"])
    m.load_state_dict(ck["model"])
    return m, ck
