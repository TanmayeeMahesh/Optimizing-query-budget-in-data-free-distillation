"""Train a student on a frozen query store. The teacher is never loaded here: zero extra queries.

loss = alpha * T^2 * KL(softmax(z_t/T) || softmax(z_s/T)) + (1 - alpha) * CE(z_s, argmax z_t)

Checkpoint selection uses agreement with the teacher on the MONITOR store (held-out natural images),
which Priyanka found ranks runs correctly (30/30 pairs), unlike agreement on held-out transfer data.
The real test set is read once at the end, for reporting only.
"""
import math
import time

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import WeightedRandomSampler

from .data import accuracy, load_logits, predict_store, predict_test, store_loader, test_loader
from .models import build_student
from .utils import exp_dir, read_json, seed_all, store_dir, device, write_json


def kd_loss(z_s, z_t, T, alpha):
    kl = F.kl_div(F.log_softmax(z_s / T, 1), F.softmax(z_t / T, 1), reduction="batchmean") * (T * T)
    if alpha >= 1.0:
        return kl
    return alpha * kl + (1.0 - alpha) * F.cross_entropy(z_s, z_t.argmax(1))


def param_groups(model, wd):
    decay = [p for p in model.parameters() if p.requires_grad and p.ndim > 1]
    no_decay = [p for p in model.parameters() if p.requires_grad and p.ndim <= 1]
    return [{"params": decay, "weight_decay": wd}, {"params": no_decay, "weight_decay": 0.0}]


def cosine_lambda(total, warmup):
    def f(step):
        if step < warmup:
            return (step + 1) / max(warmup, 1)
        return 0.5 * (1 + math.cos(math.pi * (step - warmup) / max(total - warmup, 1)))
    return f


def split_indices(n, holdout, seed):
    idx = np.random.default_rng([seed, 5]).permutation(n)
    return np.sort(idx[holdout:]), np.sort(idx[:holdout])


def make_ckpt(model, opt, sched, scaler, epoch, extra):
    return {"model": model.state_dict(), "opt": opt.state_dict(), "sched": sched.state_dict(),
            "scaler": scaler.state_dict(), "epoch": epoch, "mean": model.mean_list, "std": model.std_list, **extra}


def train_student(cfg, seed=None, run=None):
    tc = cfg["train"]
    seed = int(tc.get("seed", 0) if seed is None else seed)
    T, alpha = float(tc["temperature"]), float(tc.get("alpha", 1.0))
    sdir = store_dir(cfg, "transfer")
    if tc.get("store"):                          # use an existing store by folder name
        sdir = exp_dir(cfg) / "query" / tc["store"]
    mdir = store_dir(cfg, "monitor")
    meta = read_json(sdir / "meta.json")
    if not meta or not meta.get("complete"):
        raise RuntimeError(f"transfer store {sdir} not built; run `query` first")
    has_monitor = (read_json(mdir / "meta.json") or {}).get("complete", False)
    run = run or f"{sdir.name}_T{T:g}_a{alpha:g}_s{seed}"
    out = exp_dir(cfg) / "students" / run
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "config.json", {**cfg, "_seed": seed, "_store": str(sdir)})
    seed_all(seed)
    dev = device()
    amp = bool(tc.get("amp", True)) and dev.type == "cuda"

    N = meta["n"]
    train_idx, hold_idx = split_indices(N, int(tc.get("holdout", 0)), seed)
    sampler = None
    if tc.get("sampler", "uniform") == "balanced":       # zero-cost class balancing (Nayak / F&D spirit)
        am = np.asarray(load_logits(sdir)[train_idx], dtype=np.float32).argmax(1)
        cnt = np.bincount(am, minlength=cfg["num_classes"]).astype(np.float64)
        w = 1.0 / cnt[am]
        sampler = WeightedRandomSampler(torch.from_numpy(w), num_samples=len(train_idx), replacement=True,
                                        generator=torch.Generator().manual_seed(seed))
    bs, nw = int(tc["batch_size"]), int(tc.get("num_workers", 4))
    loader = store_loader(sdir, bs, nw, train_idx, shuffle=True, sampler=sampler, drop_last=True)
    mon_loader = store_loader(mdir, 500, 2) if has_monitor else None
    hold_loader = store_loader(sdir, 500, 2, hold_idx) if len(hold_idx) else None

    model = build_student(cfg, meta["teacher_mean"], meta["teacher_std"]).to(dev)
    model = model.to(memory_format=torch.channels_last)
    init = tc.get("init_from")
    if init and not (out / "last.pt").exists():
        model.load_state_dict(torch.load(init, map_location=dev)["model"])
        print(f"[train] initialised from {init}")
    opt = torch.optim.SGD(param_groups(model, float(tc["weight_decay"])), lr=float(tc["lr"]),
                          momentum=float(tc.get("momentum", 0.9)), nesterov=bool(tc.get("nesterov", False)))
    E = int(tc["epochs"])
    steps = E * len(loader)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, cosine_lambda(steps, int(tc.get("warmup_epochs", 0)) * len(loader)))
    scaler = torch.amp.GradScaler("cuda", enabled=amp)

    start, best = 0, -1.0
    last = out / "last.pt"
    if last.exists():
        ck = torch.load(last, map_location=dev)
        model.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"])
        sched.load_state_dict(ck["sched"]); scaler.load_state_dict(ck["scaler"])
        start, best = ck["epoch"] + 1, ck.get("best_monitor", -1.0)
        print(f"[train] resuming {run} at epoch {start}")
    student_aug = tc.get("student_aug", "none")

    for ep in range(start, E):
        model.train()
        t0, tot, agree, n = time.time(), 0.0, 0, 0
        for x, t, _ in loader:
            x = x.to(dev, non_blocking=True).float().div_(255).contiguous(memory_format=torch.channels_last)
            t = t.to(dev, non_blocking=True)
            if student_aug == "flip":   # NOTE: teacher target was computed on the unflipped image
                m = torch.rand(len(x), device=dev) < 0.5
                x = torch.where(m.view(-1, 1, 1, 1), x.flip(3), x)
            with torch.autocast("cuda", dtype=torch.float16, enabled=amp):
                z = model(x)
            loss = kd_loss(z.float(), t, T, alpha)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            sched.step()
            tot += float(loss) * len(x)
            agree += int((z.argmax(1) == t.argmax(1)).sum())
            n += len(x)
        rec = {"epoch": ep, "loss": tot / n, "train_agree": 100 * agree / n,
               "lr": opt.param_groups[0]["lr"], "sec": round(time.time() - t0, 1)}
        if mon_loader is not None:
            r = predict_store(model, mon_loader, dev, T=T, amp=amp)
            rec["monitor_agree"] = accuracy(r["probs"], r["teacher_argmax"])
            rec["monitor_kd"] = r["kd_loss"]
        if hold_loader is not None:
            r = predict_store(model, hold_loader, dev, T=T, amp=amp)
            rec["holdout_agree"] = accuracy(r["probs"], r["teacher_argmax"])
        with open(out / "metrics.jsonl", "a") as f:
            f.write(__import__("json").dumps(rec) + "\n")
        print(f"[train] {run} ep {ep:3d} " + " ".join(f"{k}={v:.4g}" for k, v in rec.items() if k != "epoch"))

        score = rec.get("monitor_agree", -1.0)
        is_best = score > best
        best = max(best, score)
        ck = make_ckpt(model, opt, sched, scaler, ep, {"best_monitor": best, "monitor_agree": score,
                                                        "store": sdir.name, "arch": cfg["student"]["arch"]})
        torch.save(ck, out / "last.pt.tmp"); (out / "last.pt.tmp").replace(last)
        if is_best and mon_loader is not None:
            torch.save({k: ck[k] for k in ("model", "epoch", "mean", "std", "monitor_agree", "store", "arch")},
                       out / "best_monitor.pt")
        se = int(tc.get("save_every", 0))
        if se and (ep + 1) % se == 0:
            torch.save({k: ck[k] for k in ("model", "epoch", "mean", "std", "monitor_agree", "store", "arch")},
                       out / f"ep{ep + 1:03d}.pt")

    # ---- final report: real test set read once per checkpoint kind
    res = {"run": run, "store": sdir.name, "teacher_queries": meta["teacher_queries"], "T": T, "alpha": alpha,
           "seed": seed, "epochs": E, "best_monitor_agree": best}
    final = {k: v for k, v in torch.load(last, map_location="cpu").items() if k in ("model", "epoch", "mean", "std")}
    torch.save(final, out / "final.pt")
    if tc.get("eval_test", "final") != "never":
        tl = test_loader(cfg)
        for name in ("final", "best_monitor"):
            p = out / f"{name}.pt"
            if p.exists():
                model.load_state_dict(torch.load(p, map_location=dev)["model"])
                probs, y = predict_test(model, tl, dev, amp)
                res[f"test_acc_{name}"] = accuracy(probs, y)
    write_json(out / "result.json", res)
    print(f"[train] {run} result: {res}")
    return out
