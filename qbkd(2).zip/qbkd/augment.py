"""Augmentation applied BEFORE the teacher is queried. Every augmented/mixed image is one query.

Presets (all on uint8 CHW tensors, torchvision.transforms.v2):
  none            nothing
  basic           RandomCrop(32, pad 4) + HFlip                          (Priyanka Part A)
  randaugment     basic + RandAugment(num_ops, magnitude)
  trivialaugment  basic + TrivialAugmentWide
  strong          basic + RandAugment(4, 14) + Elastic(p=.5) + Invert(p=.5)   (Priyanka 'strong_mix',
                  Frank & Davis synthetic regime). Mixup is configured separately (query.mixup).
  strong_trivial  same as strong but TrivialAugmentWide instead of RandAugment
"""
import numpy as np
import torch
from torchvision.transforms import v2


def build_augment(acfg, size):
    acfg = acfg or {}
    name = acfg.get("name", "strong")
    ra = acfg.get("randaugment", {"num_ops": 4, "magnitude": 14})
    crop_flip = [v2.RandomCrop(size, padding=acfg.get("pad", 4)), v2.RandomHorizontalFlip()]
    elastic = v2.RandomApply([v2.ElasticTransform(**acfg.get("elastic", {}))], p=acfg.get("elastic_p", 0.5))
    invert = v2.RandomInvert(p=acfg.get("invert_p", 0.5))

    if name == "none":
        return None
    if name == "basic":
        ops = crop_flip
    elif name == "randaugment":
        ops = crop_flip + [v2.RandAugment(**ra)]
    elif name == "trivialaugment":
        ops = crop_flip + [v2.TrivialAugmentWide()]
    elif name == "strong":
        ops = crop_flip + [v2.RandAugment(**ra), elastic, invert]
    elif name == "strong_trivial":
        ops = crop_flip + [v2.TrivialAugmentWide(), elastic, invert]
    else:
        raise KeyError(f"unknown augment preset {name!r}")
    return v2.Compose(ops)


def mixup_u8(x, mcfg, rng):
    """Function-matching mixup (Beyer et al.; Frank & Davis): blend images, the TEACHER labels the blend.

    x: uint8 [B,3,H,W]. The result is rounded back to uint8 before querying, so the stored image is
    bit-identical to what the teacher saw. Returns (x_mixed_uint8, mixed_flags bool[B]).
    """
    mcfg = mcfg or {}
    p = float(mcfg.get("p", 0.0))
    B = x.shape[0]
    if p <= 0 or B < 2:
        return x, np.zeros(B, dtype=bool)
    perm = rng.permutation(B)
    if mcfg.get("lam", "uniform") == "beta":
        a = float(mcfg.get("beta_alpha", 1.0))
        lam = rng.beta(a, a, B)
    else:
        lam = rng.uniform(0.0, 1.0, B)
    mask = rng.random(B) < p
    lam = np.where(mask, lam, 1.0).astype(np.float32)
    lam_t = torch.from_numpy(lam).view(B, 1, 1, 1)
    xf = x.float()
    out = lam_t * xf + (1.0 - lam_t) * xf[torch.from_numpy(perm)]
    return out.round_().clamp_(0, 255).to(torch.uint8), mask
