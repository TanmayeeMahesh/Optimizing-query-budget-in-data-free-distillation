"""Part 2: connect two distilled students with a low-loss curve, using ONLY the stored teacher logits.

Outputs (curves/<run>/):
  curve.pt            trained bends
  grid.json           per t: store KD loss, monitor agreement, test accuracy (reporting only)
  summary.json        endpoints vs best curve point (chosen by MONITOR agreement) vs ensembles
  best_point.pt       the selected curve point as a normal student checkpoint
  curve.png           plot
Baselines reported alongside, because a curve result means little without them:
  - each endpoint with its own BatchNorm stats, and with BN recomputed on the store (same procedure as curve points)
  - the 2-model endpoint ensemble (a curve ensemble must beat THIS, not a single model)
  - the linear path (connect.kind=linear) as a separate run
"""
import numpy as np
import torch

from .curves import Curve
from .data import accuracy, predict_store, predict_test, store_loader, test_loader
from .models import build_student
from .train import cosine_lambda, kd_loss
from .utils import device, exp_dir, read_json, seed_all, store_dir, write_json


def _auto_endpoints(cfg):
    """Top-2 student runs on the current store, ranked by monitor agreement (never by test accuracy)."""
    sdir = store_dir(cfg, "transfer")
    rows = []
    for r in (exp_dir(cfg) / "students").glob("*/result.json"):
        res = read_json(r)
        if res.get("store") == sdir.name and (r.parent / "final.pt").exists():
            rows.append((res.get("best_monitor_agree", -1), r.parent / "final.pt"))
    rows.sort(reverse=True)
    if len(rows) < 2:
        raise RuntimeError("need >= 2 finished student runs on this store (different seeds) for auto endpoints")
    print(f"[connect] auto endpoints: {rows[0][1]} , {rows[1][1]}")
    return [str(rows[0][1]), str(rows[1][1])]


def run_connect(cfg, endpoints=None, run=None):
    cc = cfg["connect"]
    T, alpha = float(cfg["train"]["temperature"]), float(cfg["train"].get("alpha", 1.0))
    seed_all(int(cc.get("seed", 0)))
    dev = device()
    amp = bool(cfg["train"].get("amp", True)) and dev.type == "cuda"
    sdir, mdir = store_dir(cfg, "transfer"), store_dir(cfg, "monitor")
    meta = read_json(sdir / "meta.json")
    has_monitor = (read_json(mdir / "meta.json") or {}).get("complete", False)

    endpoints = endpoints or cc.get("endpoints") or "auto"
    if endpoints == "auto" or endpoints == ["auto"]:
        endpoints = _auto_endpoints(cfg)
    ck0, ck1 = (torch.load(p, map_location="cpu") for p in endpoints)
    kind = cc.get("kind", "bezier")
    K = int(cc.get("num_bends", 3))
    if kind == "linear":
        kind, K = "polychain", 2
    run = run or f"{cc.get('kind', 'bezier')}{K}_" + "__".join(p.split("/")[-2] for p in endpoints)
    out = exp_dir(cfg) / "curves" / run
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "config.json", {**cfg, "_endpoints": endpoints})

    base = build_student(cfg, ck0["mean"], ck0["std"]).to(dev)
    base.load_state_dict(ck0["model"])
    curve = Curve(base, {k: v.to(dev) for k, v in ck0["model"].items()},
                  {k: v.to(dev) for k, v in ck1["model"].items()}, num_bends=K, kind=kind).to(dev)

    # ------------------------------------------------ train the bends (no teacher calls)
    bs, nw = int(cc.get("batch_size", cfg["train"]["batch_size"])), int(cfg["train"].get("num_workers", 4))
    loader = store_loader(sdir, bs, nw, shuffle=True, drop_last=True)
    E = int(cc.get("epochs", 0)) if curve.trainable() else 0
    cpath = out / "curve.pt"
    if E > 0 and cpath.exists():
        curve.load_state_dict(torch.load(cpath, map_location=dev))
        print(f"[connect] loaded trained curve {cpath}")
    elif E > 0:
        wd = float(cc.get("weight_decay", cfg["train"]["weight_decay"]))
        opt = torch.optim.SGD(curve.trainable(), lr=float(cc.get("lr", 0.03)), momentum=0.9)
        sched = torch.optim.lr_scheduler.LambdaLR(opt, cosine_lambda(E * len(loader), 0))
        scaler = torch.amp.GradScaler("cuda", enabled=amp)
        curve.base.train()
        for ep in range(E):
            tot, n = 0.0, 0
            for x, t, _ in loader:
                x = x.to(dev, non_blocking=True).float().div_(255)
                t = t.to(dev, non_blocking=True)
                u = float(np.random.uniform())          # one t per batch, as in Garipov et al.
                with torch.autocast("cuda", dtype=torch.float16, enabled=amp):
                    z = curve(x, u)
                loss = kd_loss(z.float(), t, T, alpha) + 0.5 * wd * curve.l2(u)
                opt.zero_grad(set_to_none=True)
                scaler.scale(loss).backward()
                scaler.step(opt)
                scaler.update()
                sched.step()
                tot += float(loss) * len(x)
                n += len(x)
            print(f"[connect] curve epoch {ep:3d} loss={tot / n:.4f}")
        torch.save(curve.state_dict(), cpath)

    # ------------------------------------------------ evaluate along the curve
    n_eval = min(int(cc.get("eval_store_n", 20_000)), meta["n"])
    eval_idx = np.sort(np.random.default_rng(3).choice(meta["n"], n_eval, replace=False))
    eval_loader = store_loader(sdir, 500, 2, eval_idx)
    bn_loader = store_loader(sdir, bs, nw, shuffle=True, drop_last=True)
    mon_loader = store_loader(mdir, 500, 2) if has_monitor else None
    use_test = cc.get("eval_test", True)
    tl = test_loader(cfg) if use_test else None
    bn_batches = int(cc.get("bn_batches", 100))

    def measure(model):
        r = {}
        s = predict_store(model, eval_loader, dev, T=T, amp=amp)
        r["store_kd"], r["store_agree"] = s["kd_loss"], accuracy(s["probs"], s["teacher_argmax"])
        if mon_loader is not None:
            m = predict_store(model, mon_loader, dev, T=T, amp=amp)
            r["monitor_agree"], r["_mon_probs"], r["_mon_t"] = accuracy(m["probs"], m["teacher_argmax"]), m["probs"], m["teacher_argmax"]
        if tl is not None:
            p, y = predict_test(model, tl, dev, amp)
            r["test_acc"], r["_test_probs"], r["_y"] = accuracy(p, y), p, y
        return r

    grid = np.linspace(0, 1, int(cc.get("t_grid", 21)))
    rows = []
    for t in grid:
        m = curve.materialize(float(t), bn_loader, bn_batches, dev)
        r = measure(m)
        r["t"] = float(t)
        rows.append(r)
        print(f"[connect] t={t:.2f} " + " ".join(f"{k}={v:.4g}" for k, v in r.items() if not k.startswith("_") and k != "t"))

    own = {}
    for name, ck in (("start", ck0), ("end", ck1)):
        m = build_student(cfg, ck["mean"], ck["std"]).to(dev)
        m.load_state_dict(ck["model"])
        own[name] = {k: v for k, v in measure(m).items() if not k.startswith("_")}

    def ens(members, key, ref_key):
        if not members or f"_{key}" not in members[0]:
            return None
        p = torch.stack([r[f"_{key}"] for r in members]).mean(0)
        return accuracy(p, members[0][ref_key])

    interior = rows[1:-1]
    sel_key = "monitor_agree" if mon_loader is not None else "store_kd"
    best = (max(rows, key=lambda r: r[sel_key]) if sel_key == "monitor_agree"
            else min(rows, key=lambda r: r[sel_key]))
    m_best = curve.materialize(best["t"], bn_loader, bn_batches, dev)
    torch.save({"model": m_best.state_dict(), "mean": ck0["mean"], "std": ck0["std"], "epoch": -1,
                "curve_t": best["t"], "store": sdir.name, "arch": cfg["student"]["arch"]}, out / "best_point.pt")

    summary = {
        "endpoints": endpoints, "kind": kind, "num_bends": K, "curve_epochs": E,
        "teacher_queries_used": meta["teacher_queries"], "extra_queries_for_curve": 0,
        "selection_rule": f"best t by {sel_key} (test accuracy is never used for selection)",
        "endpoint_own_bn": own,
        "endpoint_recomputed_bn": {"start": _clean(rows[0]), "end": _clean(rows[-1])},
        "best_point": _clean(best),
        "max_store_kd_on_curve": max(r["store_kd"] for r in rows),
        "ensemble_endpoints": {"test_acc": ens([rows[0], rows[-1]], "test_probs", "_y"),
                               "monitor_agree": ens([rows[0], rows[-1]], "mon_probs", "_mon_t")},
        "ensemble_curve_all_grid": {"test_acc": ens(rows, "test_probs", "_y"),
                                    "monitor_agree": ens(rows, "mon_probs", "_mon_t")},
        "ensemble_curve_interior": {"test_acc": ens(interior, "test_probs", "_y"),
                                    "monitor_agree": ens(interior, "mon_probs", "_mon_t")},
    }
    write_json(out / "grid.json", [_clean(r) for r in rows])
    write_json(out / "summary.json", summary)
    _plot(rows, out / "curve.png")
    print(f"[connect] summary -> {out / 'summary.json'}")
    return out


def _clean(r):
    return {k: v for k, v in r.items() if not k.startswith("_")}


def _plot(rows, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:  # noqa: BLE001
        return
    t = [r["t"] for r in rows]
    keys = [k for k in ("store_kd", "monitor_agree", "test_acc") if k in rows[0]]
    fig, axes = plt.subplots(1, len(keys), figsize=(4.5 * len(keys), 3.5))
    axes = np.atleast_1d(axes)
    for ax, k in zip(axes, keys):
        ax.plot(t, [r[k] for r in rows], marker="o")
        ax.set_xlabel("t along curve")
        ax.set_title(k)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
