"""Base-image sources. A source maps a base index i -> one uint8 HxWx3 image, deterministically.

Synthetic families follow Priyanka's report (Sec. 6.3) and Frank & Davis (2025):
  uniform, gauss (teacher stats), gauss_imgstats, pink (1/f^alpha), lowfreq (k x k grid), leaves
Real / rendered OOD:
  torchvision (svhn, cifar10, cifar100, stl10 ...), folder (OpenGL shader renders, TinyImageNet, anything)
"""
import zlib
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw

IMG_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".JPEG", ".PNG"}


def _to_u8(x):
    """HWC float in [0,1] -> uint8"""
    return (np.clip(x, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def _standardise(x, mean, std):
    """x: CHW float. Per-image, per-channel standardise, then map to the teacher's stats."""
    x = (x - x.mean(axis=(1, 2), keepdims=True)) / (x.std(axis=(1, 2), keepdims=True) + 1e-8)
    return x * std[:, None, None] + mean[:, None, None]


class Source:
    finite = False

    def __init__(self, size, seed, mean, std, data_root=None, **kw):
        self.size, self.seed = int(size), int(seed)
        self.mean = np.asarray(mean, np.float32)
        self.std = np.asarray(std, np.float32)
        self.data_root = data_root
        if kw:
            raise TypeError(f"{type(self).__name__}: unknown options {sorted(kw)}")

    def rng(self, i):
        return np.random.default_rng([self.seed, int(i)])

    def base(self, i):
        raise NotImplementedError


class Uniform(Source):
    def base(self, i):
        return self.rng(i).integers(0, 256, (self.size, self.size, 3), dtype=np.uint8)


class Gauss(Source):
    """i.i.d. N(mu_c, sigma_c) with the teacher's normalisation stats (Frank & Davis noise)."""

    def base(self, i):
        x = self.rng(i).normal(self.mean, self.std, (self.size, self.size, 3))
        return _to_u8(x)


class GaussImgStats(Source):
    """White noise, but every image draws its own channel means/stds (Priyanka: relH 0.544 basic)."""

    def __init__(self, mean_range=(0.1, 0.9), std_range=(0.05, 0.35), **kw):
        super().__init__(**kw)
        self.mr, self.sr = mean_range, std_range

    def base(self, i):
        r = self.rng(i)
        mu, sd = r.uniform(*self.mr, 3), r.uniform(*self.sr, 3)
        return _to_u8(r.normal(mu, sd, (self.size, self.size, 3)))


class Pink(Source):
    """Gaussian noise with amplitude spectrum ~ 1/f^alpha. alpha=2 is Priyanka's best noise ('pink2')."""

    def __init__(self, alpha=2.0, **kw):
        super().__init__(**kw)
        self.alpha = float(alpha)
        fy = np.fft.fftfreq(self.size)[:, None]
        fx = np.fft.fftfreq(self.size)[None, :]
        f = np.sqrt(fx ** 2 + fy ** 2)
        f[0, 0] = 1.0
        self.filt = 1.0 / f ** self.alpha

    def base(self, i):
        w = self.rng(i).standard_normal((3, self.size, self.size))
        x = np.real(np.fft.ifft2(np.fft.fft2(w) * self.filt))
        return _to_u8(_standardise(x, self.mean, self.std).transpose(1, 2, 0))


class LowFreq(Source):
    """k x k Gaussian grid, bicubic-upsampled, standardised to teacher stats."""

    def __init__(self, grid=4, **kw):
        super().__init__(**kw)
        self.grid = int(grid)

    def base(self, i):
        g = torch.from_numpy(self.rng(i).standard_normal((1, 3, self.grid, self.grid)).astype(np.float32))
        x = F.interpolate(g, size=(self.size, self.size), mode="bicubic", align_corners=False)[0].numpy()
        return _to_u8(_standardise(x, self.mean, self.std).transpose(1, 2, 0))


class Leaves(Source):
    """Random coloured circles/rectangles/triangles on a random background (Priyanka: 88.90%)."""

    def __init__(self, min_shapes=10, max_shapes=40, min_size=0.05, max_size=0.35, supersample=1, **kw):
        super().__init__(**kw)
        self.n = (int(min_shapes), int(max_shapes))
        self.s = (float(min_size), float(max_size))
        self.ss = int(supersample)

    def base(self, i):
        r = self.rng(i)
        S = self.size * self.ss
        col = lambda: tuple(int(c) for c in r.integers(0, 256, 3))  # noqa: E731
        im = Image.new("RGB", (S, S), col())
        d = ImageDraw.Draw(im)
        for _ in range(int(r.integers(self.n[0], self.n[1] + 1))):
            c = col()
            cx, cy = r.uniform(0, S, 2)
            rad = r.uniform(*self.s) * S
            kind = int(r.integers(0, 3))
            if kind == 0:
                d.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=c)
            elif kind == 1:
                w, h = rad * r.uniform(0.5, 1.5, 2)
                d.rectangle([cx - w, cy - h, cx + w, cy + h], fill=c)
            else:
                ang = r.uniform(0, 2 * np.pi, 3)
                d.polygon([(cx + rad * np.cos(a), cy + rad * np.sin(a)) for a in ang], fill=c)
        if self.ss > 1:
            im = im.resize((self.size, self.size), Image.BOX)
        return np.asarray(im, dtype=np.uint8)


class Folder(Source):
    """Any directory of images (OpenGL shader renders, TinyImageNet train/, ...), resized to size x size."""

    finite = True

    def __init__(self, path, **kw):
        super().__init__(**kw)
        root = Path(path)
        self.files = sorted(str(p) for p in root.rglob("*") if p.suffix in IMG_EXT)
        if not self.files:
            raise FileNotFoundError(f"no images under {root}")

    def __len__(self):
        return len(self.files)

    def base(self, i):
        im = Image.open(self.files[int(i) % len(self.files)]).convert("RGB")
        return np.asarray(im.resize((self.size, self.size), Image.BICUBIC), dtype=np.uint8)


class TorchvisionDS(Source):
    finite = True

    def __init__(self, dataset="svhn", split="train", **kw):
        super().__init__(**kw)
        import torchvision.datasets as D

        root = self.data_root or "./data"
        name = dataset.lower()
        if name == "svhn":
            self.ds = D.SVHN(root, split=split, download=True)
        elif name in ("cifar10", "cifar100"):
            cls = D.CIFAR10 if name == "cifar10" else D.CIFAR100
            self.ds = cls(root, train=(split == "train"), download=True)
        elif name == "stl10":  # split='unlabeled' gives 100k natural 96x96 images
            self.ds = D.STL10(root, split=split, download=True)
        else:
            raise KeyError(f"torchvision source {dataset!r} not wired; use type: folder")

    def __len__(self):
        return len(self.ds)

    def base(self, i):
        im = self.ds[int(i) % len(self.ds)][0].convert("RGB")
        if im.size != (self.size, self.size):
            im = im.resize((self.size, self.size), Image.BICUBIC)
        return np.asarray(im, dtype=np.uint8)


REGISTRY = {
    "uniform": Uniform,
    "gauss": Gauss,
    "gauss_imgstats": GaussImgStats,
    "pink": Pink,
    "lowfreq": LowFreq,
    "leaves": Leaves,
    "folder": Folder,
    "torchvision": TorchvisionDS,
}
META_KEYS = ("type", "weight", "views_per_base")


def build_source(label, scfg, size, base_seed, mean, std, data_root):
    scfg = dict(scfg or {})
    typ = scfg.get("type", label)
    if typ not in REGISTRY:
        raise KeyError(f"source {label!r}: unknown type {typ!r}; known {sorted(REGISTRY)}")
    kw = {k: v for k, v in scfg.items() if k not in META_KEYS}
    seed = (int(base_seed) * 1_000_003 + zlib.crc32(label.encode())) % (2 ** 32)
    return REGISTRY[typ](size=size, seed=seed, mean=mean, std=std, data_root=data_root, **kw)
